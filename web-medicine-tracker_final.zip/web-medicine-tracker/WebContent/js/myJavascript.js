function showPassword() {
  var x = document.getElementById("pwd");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function onLoadDashboard()
{
	var welcomeMsg = document.getElementById("welcomeMsg");
	welcomeMsg.innerHTML = sessionStorage.getItem("user_name")+", Welcome to the Dashboard! ";
}

function validateLoginForm() {
	var userName = document.getElementById("userName");
	var pwd = document.getElementById("pwd");
	if(userName.value === "admin" && pwd.value === "admin")
	{
  		sessionStorage.setItem("isAdmin","true");
	}
	else
	{
		sessionStorage.setItem("user_name",userName.value);	
	}
	
}

function validateQty()
{
	var qty = document.getElementById("qty");
	
	if(qty.value < 0)
	{
		alert("Please enter a positive quantity");
	}
}
function calculateTotal() {
	var price = document.getElementById("price");
	var qty = document.getElementById("qty");
	var orderTotal = document.getElementById("orderTotal");
	if(price.value && qty.value)
	{
		orderTotal.value = price.value * qty.value;
	}
	
}


function onLoadComplete(){
	
	var isAdminFromSession = sessionStorage.getItem("isAdmin");
	if(isAdminFromSession == "true")
	{
		document.getElementById("adminDashboard").style.display = "inline-block";
		document.getElementById("dashboard").style.display = "none";
	}
	else
	{
		document.getElementById("adminDashboard").style.display = "none";
		document.getElementById("dashboard").style.display = "inline-block";
		document.getElementById("addButton").style.display = "none";
		document.getElementById("actionHeader").style.display = "none";
		document.querySelectorAll('.actionData').forEach(function(el) {
			   el.style.display = 'none';
		});
	}
}

function onLoadCompleteOrders(){
	
	var isAdminFromSession = sessionStorage.getItem("isAdmin");
	if(isAdminFromSession == "true")
	{
		document.getElementById("adminDashboard").style.display = "inline-block";
		document.getElementById("dashboard").style.display = "none";
	}
	else
	{
		document.getElementById("adminDashboard").style.display = "none";
		document.getElementById("dashboard").style.display = "inline-block";
	}
}


function logout(){
	sessionStorage.clear();
	window.location.href = "user-login.jsp";
}