package com.examples.web.jdbc;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class StockControllerServlet
 */
@WebServlet("/OrderControllerServlet")
public class OrderControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private OrderDbUtil orderDbUtil;
	private StockOrderDbUtil stockOrderDbUtil;
	private CustomerDbUtil customerDbUtil;
	private PharmacistDbUtil pharmacistDbUtil;
	private StockDbUtil stockDbUtil;
	
	@Resource(name="jdbc/web_medicine_tracker")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		// create our stock db util ... and pass in the conn pool / datasource
		try {
			orderDbUtil = new OrderDbUtil(dataSource);
			stockOrderDbUtil = new StockOrderDbUtil(dataSource);
			customerDbUtil = new CustomerDbUtil(dataSource);
			pharmacistDbUtil = new PharmacistDbUtil(dataSource);
			stockDbUtil = new StockDbUtil(dataSource);
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			// if the command is missing, then default to listing stocks
			if (theCommand == null) {
				theCommand = "SEARCH";
			}
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "LIST":
				listOrders(request, response);
				break;
				
			case "ADD":
				addOrder(request, response);
				break;
				
			case "LOAD_DETAILS":
				loadOrderDetails(request, response);
				break;
				
			case "DELETE":
				deleteOrder(request, response);
				break;
				
			case "SEARCH":
				searchOrderByCust_Id(request, response);
				break;
				
			default:
				listOrders(request, response);
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		
	}
	
	private void searchOrderByCust_Id(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		// read customer id from form data
		String theCustomerId = request.getParameter("inputCustId");
		List<Order> orders = null;
		if(theCustomerId != null && !"".equals(theCustomerId))
		{
			int customerId = Integer.parseInt(theCustomerId);
			// get orders from db util
			orders = orderDbUtil.getOrdersByCustomerId(customerId);
		}
		else {
			orders = orderDbUtil.getOrders();
		}

		// add students to the request
		request.setAttribute("ORDER_LIST", orders);

		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-orders.jsp");
		dispatcher.forward(request, response);
	}

	private void deleteOrder(HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		// read order id from form data
		String theOrderId = request.getParameter("orderId");

		int orderId = Integer.parseInt(theOrderId);
		//increase the stock by orderQty because we are deleting the order
		Order theOrder = orderDbUtil.getOrder(orderId);
		StockOrder theStockOrder = stockOrderDbUtil.getStockOrderByOrderId(orderId);

		Stock theStock = stockDbUtil.getStock(theStockOrder.getStockId());
		int finalStockQty = theStock.getQuantity() + theOrder.getOrderQty();
		
		theStock.setQuantity(finalStockQty);
		
		stockDbUtil.updateStock(theStock);
		
		// delete order from database, which will delete entry from stockorder as well due to cascade delete
		orderDbUtil.deleteOrder(theOrderId);
		
		// send them back to "list orders" page
		listOrders(request, response);
	}
	
	@SuppressWarnings("unused")
	private void addOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// read stock info from form data
		//String orderIdStr = request.getParameter("orderId");
		String orderDateStr = request.getParameter("orderDate");
		String drugName = request.getParameter("drugName");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int price = Integer.parseInt(request.getParameter("price"));
		int orderTotal = Integer.parseInt(request.getParameter("orderTotal"));
		String customerFirstName = request.getParameter("customerFirstName");
		String customerLastName = request.getParameter("customerLastName");
		String pharmacistName = request.getParameter("pharmacistName");
		
		Stock theStock = stockDbUtil.getStockByName(drugName);
		
		
		if(theStock == null) 
		{
			String msg = "The drug doesn't exist in DB : "+drugName;
			request.setAttribute("errorMsg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-order-form.jsp");
			dispatcher.forward(request, response);
			return;
		}
		//validate Quantity
		if(quantity < 0)
		{
			String msg = "Please enter a positive quantity";
			request.setAttribute("errorMsg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-order-form.jsp");
			dispatcher.forward(request, response);
			return;
		}
		int stockFinalQty = theStock.getQuantity() - quantity;
		if(stockFinalQty < 0)
		{
			String msg = "Ordered quantity exceeds stock quantity : "+theStock.getQuantity();
			request.setAttribute("errorMsg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-order-form.jsp");
			dispatcher.forward(request, response);
			return;
		}
		

		//find the customerId from customerName
		Customer theCustomer = customerDbUtil.getCustomerByName(customerFirstName,customerLastName);
		if(theCustomer == null)
		{
			String msg = "The customer doesn't exist in DB : "+customerFirstName+" "+customerLastName;
			request.setAttribute("errorMsg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-order-form.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		//Get stockId and PharmacistId by name to make an entry in stockorder
		Pharmacist thePharmacist = pharmacistDbUtil.getPharmacistByName(pharmacistName);
		if(thePharmacist == null)
		{
			String msg = "The pharmacist doesn't exist in DB : "+pharmacistName;
			request.setAttribute("errorMsg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-order-form.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		//get next orderId
		int orderId = orderDbUtil.getNextOrderId();
		
		//parse the orderDate
		SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd");
		isoFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date orderDate = isoFormat.parse(orderDateStr);
		
		// create a new order object
		Order theOrder = new Order(orderId,orderDate, quantity, orderTotal, theCustomer.getId());
		
		//Add entry in orders
		orderDbUtil.addOrder(theOrder);
		
		
		
		//create new stockorder object
		StockOrder theStockOrder = new StockOrder(orderId,theStock.getId(),thePharmacist.getId());
		//Add entry in stockorder
		stockOrderDbUtil.addStockOrder(theStockOrder);
		
		//update the stock - decrease quantity of drug by orderQty
		
		theStock.setQuantity(stockFinalQty);
		
		stockDbUtil.updateStock(theStock);
				
		// send back to main page (the order list)
		listOrders(request, response);
	}

	private void listOrders(HttpServletRequest request, HttpServletResponse response) 
		throws Exception {

		// get orders from db util
		List<Order> orders = orderDbUtil.getOrders();
		
		// add students to the request
		request.setAttribute("ORDER_LIST", orders);
				
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-orders.jsp");
		dispatcher.forward(request, response);
	}
	
	private void loadOrderDetails(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {

		// read order id from form data
		String theOrderId = request.getParameter("orderId");

		// convert theOrderId to int
		int orderId = Integer.parseInt(theOrderId);
					
		// get order and stockorder from database (db util)
		Order theOrder = orderDbUtil.getOrder(orderId);
		StockOrder theStockOrder = stockOrderDbUtil.getStockOrderByOrderId(orderId);
		//get other objects from DB
		Stock theStock = stockDbUtil.getStock(theStockOrder.getStockId());
		Pharmacist thePharmacist = pharmacistDbUtil.getPharmacist(theStockOrder.getPharmacistId());
		Customer theCustomer = customerDbUtil.getCustomer(theOrder.getCustomerId());
		
		
		OrderDetails theOrderDetails = stockOrderDbUtil.createOrderDetails(theOrder,theStock,thePharmacist,theCustomer);
		// place stock in the request attribute
		request.setAttribute("THE_ORDER_DETAILS", theOrderDetails);

		// send to jsp page: update-stock-form.jsp
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/list-order-details.jsp");
		dispatcher.forward(request, response);	
	}

}

