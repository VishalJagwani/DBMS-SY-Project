package com.examples.web.jdbc;

import java.util.Date;

public class Order {

	private int id;
	private Date orderDate;
	
	private int orderQty;
	private int orderTotal;
	private int customerId;
	private Date oLastUpdationDate;
	
	public Order(Date orderDate, int orderQty,int orderTotal,int customerId) {
		this.orderDate = orderDate;
		this.orderQty = orderQty;
		this.orderTotal = orderTotal;
		this.customerId = customerId;
	}

	public Order(int id, Date orderDate, int orderQty,int orderTotal, int customerId) {
		this.id = id;
		this.orderDate = orderDate;
		this.orderQty = orderQty;
		this.orderTotal = orderTotal;
		this.customerId = customerId;
	}
	
	public Order(int id, Date orderDate, int orderQty,int orderTotal, int customerId, Date oLastUpdationDate) {
		this.id = id;
		this.orderDate = orderDate;
		this.orderQty = orderQty;
		this.orderTotal = orderTotal;
		this.customerId = customerId;
		this.oLastUpdationDate = oLastUpdationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}

	public int getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(int orderTotal) {
		this.orderTotal = orderTotal;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Date getoLastUpdationDate() {
		return oLastUpdationDate;
	}

	public void setoLastUpdationDate(Date oLastUpdationDate) {
		this.oLastUpdationDate = oLastUpdationDate;
	}
	
	@Override
	public String toString() {
		return "order [id = " + id + ", orderDate = " + orderDate + ", orderQty = " + orderQty + ", "
				+ "orderTotal = " + orderTotal + ", customerId = " + customerId + ", oLastUpdationDate = " + oLastUpdationDate + "]";
	}	
}
