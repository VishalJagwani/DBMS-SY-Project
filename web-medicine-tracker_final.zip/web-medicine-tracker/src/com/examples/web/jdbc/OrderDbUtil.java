package com.examples.web.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

public class OrderDbUtil {

	private DataSource dataSource;

	public OrderDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Order> getOrders() throws Exception {
		
		List<Order> orders = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select * from orders";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int id = myRs.getInt("id");
				
				Date orderDate = myRs.getDate("orderDate");
				int orderQty = myRs.getInt("orderQty");
				int orderTotal = myRs.getInt("orderTotal");
				int customerId = myRs.getInt("customerId");
				Date oLastUpdationDate = myRs.getDate("oLastUpdationDate");
				
				// create new order object
				Order tempOrder = new Order(id, orderDate, orderQty, orderTotal,customerId,oLastUpdationDate);
				
				// add it to the list of orders
				orders.add(tempOrder);				
			}
			
			return orders;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();   // doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addOrder(Order theOrder) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into orders "
					   + "(id, orderDate , orderQty , orderTotal , customerId) "
					   + "values (?, ?, ?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			// set the param values for the stock
			myStmt.setInt(1, theOrder.getId());
			
			java.sql.Date orderDateSql = new java.sql.Date(theOrder.getOrderDate().getTime());
			
			//java.sql.Date orderDateSql = (java.sql.Date)theOrder.getOrderDate();
			
			myStmt.setObject(2,orderDateSql);
			myStmt.setInt(3, theOrder.getOrderQty());
			myStmt.setInt(4, theOrder.getOrderTotal());
			myStmt.setInt(5, theOrder.getCustomerId());
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public Order getOrder(int orderId) throws Exception {

		Order order = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected order
			String sql = "select * from orders where id=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, orderId);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				int id = myRs.getInt("id");
				Date orderDate = myRs.getDate("orderDate");
				int orderQty = myRs.getInt("orderQty");
				int orderTotal = myRs.getInt("orderTotal");
				int customerId = myRs.getInt("customerId");
				Date oLastUpdationDate = myRs.getDate("oLastUpdationDate");
				
				
				// use the orderId during construction
				order = new Order(orderId, orderDate, orderQty, orderTotal, customerId,oLastUpdationDate);
			}
			else {
				throw new Exception("Could not find order id: " + orderId);
			}				
			
			return order;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}


	public void deleteOrder(String theStockId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// convert stock id to int
			int stockId = Integer.parseInt(theStockId);
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to delete stock
			String sql = "delete from orders where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, stockId);
			
			// execute sql statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}	
	}

	public int getNextOrderId() throws Exception {
		int nextOrderId = 0;
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select max(id) as maxOrderId from orders";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			int maxOrderId = 0;
			// process result set
			if(myRs.next()){
				maxOrderId = myRs.getInt("maxOrderId");
			}
			
				
			nextOrderId = maxOrderId+1;
			
			return nextOrderId;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public List<Order> getOrdersByCustomerId(int cust_Id) throws Exception {
		
		List<Order> orders = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			CallableStatement cstmt = myConn.prepareCall("{call GetOrdersByCustomerId(?)}");
			cstmt.setInt("custId",cust_Id);
			
			// execute query
			myRs = cstmt.executeQuery();
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int id = myRs.getInt("id");
				Date orderDate = myRs.getDate("orderDate");
				int orderQty = myRs.getInt("orderQty");
				int orderTotal = myRs.getInt("orderTotal");
				int customerId = myRs.getInt("customerId");
				Date oLastUpdationDate = myRs.getDate("oLastUpdationDate");
				
				// create new order object
				Order tempOrder = new Order(id, orderDate, orderQty, orderTotal,customerId,oLastUpdationDate);
				
				// add it to the list of orders
				orders.add(tempOrder);				
			}
			
			return orders;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	
}

