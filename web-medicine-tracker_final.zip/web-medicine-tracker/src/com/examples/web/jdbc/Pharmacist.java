package com.examples.web.jdbc;

import java.util.Date;

public class Pharmacist {

	private int id;
	private String userName;
	private String pwd;
	private boolean isAdmin;
	private Date pLastUpdationDate;

	public Pharmacist(String userName, String pwd, boolean isAdmin) {
		this.userName = userName;
		this.pwd = pwd;
		this.isAdmin = isAdmin;
	}

	public Pharmacist(int id, String userName,String pwd, boolean isAdmin) {
		this.id = id;
		this.userName = userName;
		this.pwd = pwd;
		this.isAdmin = isAdmin;
	}
	
	public Pharmacist(int id, String userName,String pwd, boolean isAdmin, Date pLastUpdationDate) {
		this.id = id;
		this.userName = userName;
		this.pwd = pwd;
		this.isAdmin = isAdmin;
		this.pLastUpdationDate = pLastUpdationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	public Date getpLastUpdationDate() {
		return pLastUpdationDate;
	}

	public void setpLastUpdationDate(Date pLastUpdationDate) {
		this.pLastUpdationDate = pLastUpdationDate;
	}

	@Override
	public String toString() {
		return "Pharmacist [id = " + id + ", userName = " + userName + ", pwd = " + pwd + ", isAdmin = " + isAdmin + ", pLastUpdationDate = " + pLastUpdationDate + "]";
	}	
}
