package com.examples.web.jdbc;

import java.util.Date;

public class OrderDetails {

	private int id;
	private Date orderDate;	
	private int orderQty;
	private int orderTotal;
	private String customerFirstName;
	private String customerLastName;
	private String drugName;
	private String pharmacistName;
	
	
	public OrderDetails(int id,Date orderDate, int orderQty,int orderTotal,String customerFirstName,String customerLastName, String drugName, String pharmacistName) {
		this.id = id;
		this.orderDate = orderDate;
		this.orderQty = orderQty;
		this.orderTotal = orderTotal;
		this.customerFirstName = customerFirstName;
		this.customerLastName = customerLastName;
		this.drugName = drugName;
		this.pharmacistName = pharmacistName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}

	public int getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(int orderTotal) {
		this.orderTotal = orderTotal;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public String getPharmacistName() {
		return pharmacistName;
	}

	public void setPharmacistName(String pharmacistName) {
		this.pharmacistName = pharmacistName;
	}

	@Override
	public String toString() {
		return "orderDetails [id = " + id + ", orderDate = " + orderDate + ", orderQty = " + orderQty + ", "
				+ "orderTotal = " + orderTotal  + ", customerFirstName = " + customerFirstName + ", customerLastName = " + customerLastName + ", drugName = " + drugName + ", pharmacistName = " + pharmacistName + "]";
	}	
}
