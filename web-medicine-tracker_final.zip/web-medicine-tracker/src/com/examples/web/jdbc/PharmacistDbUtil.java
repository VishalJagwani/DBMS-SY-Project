package com.examples.web.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

public class PharmacistDbUtil {

	private DataSource dataSource;

	public PharmacistDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Pharmacist> getPharmacists() throws Exception {
		
		List<Pharmacist> pharmacists = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select * from pharmacist";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int id = myRs.getInt("id");
				String userName = myRs.getString("userName");
				String pwd = myRs.getString("pwd");
				int isAdminInt = myRs.getInt("isAdmin");
				Date pLastUpdationDate = myRs.getDate("pLastUpdationDate");
				
				boolean isAdmin = false;
				if(isAdminInt == 1)
					isAdmin = true;
			
				// create new pharmacist object
				Pharmacist tempPharmacist = new Pharmacist(id, userName, pwd, isAdmin, pLastUpdationDate);
				
				// add it to the list of stocks
				pharmacists.add(tempPharmacist);				
			}
			
			return pharmacists;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();   // doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addPharmacist(Pharmacist thePharmacist) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into pharmacist "
					   + "(userName , pwd , isAdmin) "
					   + "values (?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			int isAdminInt = 0;
			if (thePharmacist.getIsAdmin())
				isAdminInt =1;
			
			// set the param values for the pharmacist
			myStmt.setString(1, thePharmacist.getUserName());
			myStmt.setString(2, thePharmacist.getPwd());
			myStmt.setInt(3, isAdminInt);
			
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public Pharmacist getPharmacist(int pharmacistId) throws Exception {

		Pharmacist pharmacist = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected pharmacist
			String sql = "select * from pharmacist where id=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, pharmacistId);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				String userName = myRs.getString("userName");
				String pwd = myRs.getString("pwd");
				int isAdminInt = myRs.getInt("isAdmin");
				Date pLastUpdationDate = myRs.getDate("pLastUpdationDate");
				
				
				boolean isAdmin = false;
				if(isAdminInt == 1)
					isAdmin = true;
				// use the pharmacistId during construction
				pharmacist = new Pharmacist(pharmacistId, userName, pwd, isAdmin, pLastUpdationDate);
			}
			else {
				throw new Exception("Could not find pharmacist id: " + pharmacistId);
			}				
			
			return pharmacist;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void updatePharmacist(Pharmacist thePharmacist) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create SQL update statement
			String sql = "update pharmacist "
						+ "set userName=?, pwd=?, isAdmin=? "
						+ "where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			int isAdminInt = 0;
			if(thePharmacist.getIsAdmin())
				isAdminInt =1;
			// set params
			myStmt.setString(1, thePharmacist.getUserName());
			myStmt.setString(2, thePharmacist.getPwd());
			myStmt.setInt(3, isAdminInt);
			myStmt.setInt(4, thePharmacist.getId());
			
			
			// execute SQL statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public void deletePharmacist(String thePharmacistId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// convert pharmacist id to int
			int pharmacistId = Integer.parseInt(thePharmacistId);
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to delete pharmacist
			String sql = "delete from pharmacist where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, pharmacistId);
			
			// execute sql statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}	
	}

	public boolean loginPharmacist(Pharmacist thePharmacist) throws Exception {
		boolean loginSuccessful = false;
		
		//read the pharmacists from DB
		List<Pharmacist> pharmacists = getPharmacists();
		
		//check if currentUser exist, if yes, then login successful
		for(Pharmacist pharmacist: pharmacists)
		{
			if(pharmacist.getUserName().equals(thePharmacist.getUserName())
				&& pharmacist.getPwd().equals(thePharmacist.getPwd()))
			{
				loginSuccessful = true;
				return loginSuccessful;
			}
		}
		
		//Login was not successful
		loginSuccessful = false;
		
		return loginSuccessful;
	}
	

	public boolean registerPharmacist(Pharmacist thePharmacist) throws Exception {

		boolean registeredSuccessfully = false;
		//read the pharmacists from DB
		List<Pharmacist> pharmacists = getPharmacists();
		
		//check if currentUser doesn't exist, then add it to databse
		for(Pharmacist pharmacist: pharmacists)
		{
			if(pharmacist.getUserName().equalsIgnoreCase(thePharmacist.getUserName()))
			{
				registeredSuccessfully = false;
				return registeredSuccessfully;
			}
		}
		
		//add pharmacist to the DB
		addPharmacist(thePharmacist);
		registeredSuccessfully = true;
		
		return registeredSuccessfully;
	}

	public Pharmacist getPharmacistByName(String pharmacistName) throws Exception {

		Pharmacist pharmacist = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected pharmacist
			String sql = "select * from pharmacist where userName=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, pharmacistName);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				int id = myRs.getInt("id");
				String userName = myRs.getString("userName");
				String pwd = myRs.getString("pwd");
				int isAdminInt = myRs.getInt("isAdmin");
				Date pLastUpdationDate = myRs.getDate("pLastUpdationDate");
				
				boolean isAdmin = false;
				if(isAdminInt == 1)
					isAdmin = true;
				// use the pharmacistId during construction
				pharmacist = new Pharmacist(id, userName, pwd, isAdmin, pLastUpdationDate);
			}
							
			
			return pharmacist;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}


}

