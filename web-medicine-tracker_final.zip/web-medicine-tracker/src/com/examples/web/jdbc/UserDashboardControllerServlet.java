package com.examples.web.jdbc;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 * Servlet implementation class StockControllerServlet
 */
@WebServlet("/UserDashboardControllerServlet")
public class UserDashboardControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private StockDbUtil stockDbUtil;
	private PharmacistDbUtil pharmacistDbUtil;
	private CustomerDbUtil customerDbUtil;
	private OrderDbUtil orderDbUtil;
	
	
	@Resource(name="jdbc/web_medicine_tracker")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		// create our customer db util ... and pass in the conn pool / datasource
		try {
			stockDbUtil = new StockDbUtil(dataSource);
			pharmacistDbUtil = new PharmacistDbUtil(dataSource);
			customerDbUtil = new CustomerDbUtil(dataSource);
			orderDbUtil = new OrderDbUtil(dataSource);
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "LIST_STOCKS":
				listStocks(request, response);
				break;
				
			case "LIST_PHARMACISTS": 
				listPharmacists(request, response); 
				break;
			  
			case "LIST_CUSTOMERS": 
				listCustomers(request, response); 
				break;
			  
			case "LIST_ORDERS": 
				listOrders(request, response); 
				break;
			 
					 	
			default:
				listStocks(request, response);
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		
	}

	
	
	private void listStocks(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {

		// get stocks from db util
		List<Stock> stocks = stockDbUtil.getStocks();

		// add stocks to the request
		request.setAttribute("STOCK_LIST", stocks);
		
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-stocks.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listPharmacists(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		// get pharmacists from db util
		List<Pharmacist> pharmacists = pharmacistDbUtil.getPharmacists();
		
		// add pharmacists to the request
		request.setAttribute("PHARMACIST_LIST", pharmacists);

			
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-pharmacists.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listCustomers(HttpServletRequest request, HttpServletResponse response) 
		throws Exception {

		// get customers from db util
		List<Customer> customers = customerDbUtil.getCustomers();
		
		// add customers to the request
		request.setAttribute("CUSTOMER_LIST", customers);

				
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-customers.jsp");
		dispatcher.forward(request, response);
	}

	private void listOrders(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {

		// get orders from db util
		List<Order> orders = orderDbUtil.getOrders();

		// add orders to the request
		request.setAttribute("ORDER_LIST", orders);
		
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-orders.jsp");
		dispatcher.forward(request, response);
	}
}

