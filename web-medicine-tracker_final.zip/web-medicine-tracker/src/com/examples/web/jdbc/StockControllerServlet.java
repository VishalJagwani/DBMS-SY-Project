package com.examples.web.jdbc;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class StockControllerServlet
 */
@WebServlet("/StockControllerServlet")
public class StockControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private StockDbUtil stockDbUtil;
	
	@Resource(name="jdbc/web_medicine_tracker")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		// create our stock db util ... and pass in the conn pool / datasource
		try {
			stockDbUtil = new StockDbUtil(dataSource);
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			// if the command is missing, then default to listing stocks
			if (theCommand == null) {
				theCommand = "LIST";
			}
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "LIST":
				listStocks(request, response);
				break;
				
			case "ADD":
				addStock(request, response);
				break;
				
			case "LOAD":
				loadStock(request, response);
				break;
				
			case "UPDATE":
				updateStock(request, response);
				break;
			
			case "DELETE":
				deleteStock(request, response);
				break;
				
			default:
				listStocks(request, response);
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		
	}

	private void deleteStock(HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		// read stock id from form data
		String theStockId = request.getParameter("stockId");
		
		// delete stock from database
		stockDbUtil.deleteStock(theStockId);
		
		// send them back to "list stocks" page
		listStocks(request, response);
	}

	private void updateStock(HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		// read stock info from form data
		int id = Integer.parseInt(request.getParameter("stockId"));
		String drugName = request.getParameter("drugName");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int price = Integer.parseInt(request.getParameter("price"));
		String stock_status = request.getParameter("stock_status");
		
		// create a new stock object
		Stock theStock = new Stock(id, drugName, quantity, price, stock_status);
		
		// perform update on database
		stockDbUtil.updateStock(theStock);
		
		// send them back to the "list stocks" page
		listStocks(request, response);
		
	}

	private void loadStock(HttpServletRequest request, HttpServletResponse response) 
		throws Exception {

		// read stock id from form data
		String theStockId = request.getParameter("stockId");
		
		// convert theStockId to int
		int stockId = Integer.parseInt(theStockId);
		
		// get stock from database (db util)
		Stock theStock = stockDbUtil.getStock(stockId);
		
		// place stock in the request attribute
		request.setAttribute("THE_STOCK", theStock);
		
		// send to jsp page: update-stock-form.jsp
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/update-stock-form.jsp");
		dispatcher.forward(request, response);		
	}

	private void addStock(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// read stock info from form data
		String drugName = request.getParameter("drugName");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int price = Integer.parseInt(request.getParameter("price"));
		String stock_status = request.getParameter("stock_status");		
		
		// create a new stock object
		Stock theStock = new Stock(drugName, quantity, price, stock_status);
		
		// add the stock to the database
		stockDbUtil.addStock(theStock);
				
		// send back to main page (the stock list)
		listStocks(request, response);
	}

	private void listStocks(HttpServletRequest request, HttpServletResponse response) 
		throws Exception {

		// get stocks from db util
		List<Stock> stocks = stockDbUtil.getStocks();
		
		// add students to the request
		request.setAttribute("STOCK_LIST", stocks);
				
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-stocks.jsp");
		dispatcher.forward(request, response);
	}

}

