package com.examples.web.jdbc;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class StockControllerServlet
 */
@WebServlet("/CustomerControllerServlet")
public class CustomerControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CustomerDbUtil customerDbUtil;
	
	@Resource(name="jdbc/web_medicine_tracker")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		// create our customer db util ... and pass in the conn pool / datasource
		try {
			customerDbUtil = new CustomerDbUtil(dataSource);
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			// if the command is missing, then default to listing stocks
			if (theCommand == null) {
				theCommand = "LIST";
			}
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "LIST":
				listCustomers(request, response);
				break;
				
			case "ADD": 
				addCustomer(request, response); 
				break;
			  
			case "LOAD": 
				loadCustomer(request, response); 
				break;
			  
			case "UPDATE": 
				updateCustomer(request, response); 
				break;
			 
			case "DELETE": 
				deleteCustomer(request, response); 
				break;
			 	
			default:
				listCustomers(request, response);
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		
	}

	
	private void deleteCustomer(HttpServletRequest request, HttpServletResponse
			response) throws Exception {

		// read customer id from form data 
		String theCustomerId =	request.getParameter("customerId");

		// delete customer from database 
		customerDbUtil.deleteCustomer(theCustomerId);

		// send them back to "list customers" page 
		listCustomers(request, response); 
	}
	  
	private void updateCustomer(HttpServletRequest request, HttpServletResponse response)
			throws Exception {

			// read customer info from form data
			int id = Integer.parseInt(request.getParameter("customerId"));
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String address = request.getParameter("address");
			
			// create a new stock object
			Customer theCustomer = new Customer(id, firstName, lastName, address);
			
			// perform update on database
			customerDbUtil.updateCustomer(theCustomer);
			
			// send them back to the "list customers" page
			listCustomers(request, response);
			
		}

	private void loadCustomer(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {

		// read customer id from form data
		String theCustomerId = request.getParameter("customerId");

		// convert theCustomerId to int
		int customerId = Integer.parseInt(theCustomerId);
					
		// get customer from database (db util)
		Customer theCustomer = customerDbUtil.getCustomer(customerId);

		// place customer in the request attribute
		request.setAttribute("THE_CUSTOMER", theCustomer);

		// send to jsp page: update-customer-form.jsp
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/update-customer-form.jsp");
		dispatcher.forward(request, response);		
	}

	private void addCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// read customer info from form data
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String address = request.getParameter("address");
		
		// create a new customer object
		Customer theCustomer = new Customer(firstName, lastName, address);

		// add the customer to the database
		customerDbUtil.addCustomer(theCustomer);

		// send back to main page (the stock list)
		listCustomers(request, response);
	}

	
	private void listCustomers(HttpServletRequest request, HttpServletResponse response) 
		throws Exception {

		// get customers from db util
		List<Customer> customers = customerDbUtil.getCustomers();
		
		// add students to the request
		request.setAttribute("CUSTOMER_LIST", customers);
				
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-customers.jsp");
		dispatcher.forward(request, response);
	}

}

