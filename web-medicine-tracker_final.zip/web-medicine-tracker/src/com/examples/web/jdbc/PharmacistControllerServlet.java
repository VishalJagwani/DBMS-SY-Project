package com.examples.web.jdbc;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class PharmacistControllerServlet
 */
@WebServlet("/PharmacistControllerServlet")
public class PharmacistControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PharmacistDbUtil pharmacistDbUtil;
	
	@Resource(name="jdbc/web_medicine_tracker")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		// create our stock db util ... and pass in the conn pool / datasource
		try {
			pharmacistDbUtil = new PharmacistDbUtil(dataSource);
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PharmacistControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			// if the command is missing, then default to listing pharmacists
			if (theCommand == null) {
				theCommand = "LIST";
			}
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "LIST":
				listPharmacists(request, response);
				break;
			
			case "ADD": 
				addPharmacist(request, response); 
				break;
			  
			
			case "LOAD": 
				loadPharmacist(request, response); 
				break;
			  
			case "UPDATE": 
				updatePharmacist(request, response); 
				break;
			   
			case "DELETE": 
				 deletePharmacist(request, response); 
				 break;
			 	
			default:
				listPharmacists(request, response);
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		

	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// read the "command" parameter
			String theCommand = request.getParameter("command");
			
			// route to the appropriate method
			switch (theCommand) {
			
			case "REGISTER":
				registerUser(request, response);
				break;
				
			case "LOGIN":
				loginUser(request, response);
				break;
			}
				
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
		
	}


	private void deletePharmacist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// read pharmacist id from form data
		String thePharmacistId = request.getParameter("pharmacistId");

		// delete pharmacist from database
		pharmacistDbUtil.deletePharmacist(thePharmacistId);

		// send them back to "list pharmacists" page
		listPharmacists(request, response);
		
	}

	private void updatePharmacist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {

			// read pharmacist info from form data
			int id = Integer.parseInt(request.getParameter("pharmacistId"));
			String userName = request.getParameter("userName");
			String pwd = request.getParameter("pwd");
			boolean isAdmin = false;
			
			// create a new pharmacist object
			Pharmacist thePharmacist = new Pharmacist(id, userName, pwd, isAdmin);
			
			// perform update on database
			pharmacistDbUtil.updatePharmacist(thePharmacist);
			
			// send them back to the "list pharmacists" page
			listPharmacists(request, response);
			
	}

	private void loadPharmacist(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {

		// read pharmacist id from form data
		String thePharmacistId = request.getParameter("pharmacistId");
		
		// convert thePharmacistId to int
		int pharmacistId = Integer.parseInt(thePharmacistId);
					

		// get stock from database (db util)
		Pharmacist thePharmacist = pharmacistDbUtil.getPharmacist(pharmacistId);

		// place stock in the request attribute
		request.setAttribute("THE_PHARMACIST", thePharmacist);

		// send to jsp page: update-stock-form.jsp
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/update-pharmacist-form.jsp");
		dispatcher.forward(request, response);		
	}

	
	private void addPharmacist(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		// read pharmacist info from form data
		String userName = request.getParameter("userName");
		String pwd = request.getParameter("pwd");
		boolean isAdmin = false;
		
		// create a new pharmacist object
		Pharmacist thePharmacist = new Pharmacist(userName, pwd, isAdmin);

		// add the pharmacist to the database
		pharmacistDbUtil.addPharmacist(thePharmacist);

		// send back to main page (the pharmacist list)
		listPharmacists(request, response);
		
	}
	
	private void listPharmacists(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		// get pharmacists from db util
		List<Pharmacist> pharmacists = pharmacistDbUtil.getPharmacists();
		
		// add pharmacists to the request
		request.setAttribute("PHARMACIST_LIST", pharmacists);
				
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-pharmacists.jsp");
		dispatcher.forward(request, response);
	}

	private void loginUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// read pharmacist info from form data
		String userName = request.getParameter("userName");
		String pwd = request.getParameter("pwd");

		if("admin".equals(userName) && "admin".equals(pwd))
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-dashboard.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		boolean isAdmin = false;

		// create a new pharmacist object
		Pharmacist thePharmacist = new Pharmacist(userName, pwd, isAdmin);
		boolean loginSuccessful = false;
		// check for Login
		try {
			loginSuccessful = pharmacistDbUtil.loginPharmacist(thePharmacist);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if(loginSuccessful)
		{
			request.setAttribute("user_name", userName);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/dashboard.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Username or password is incorrect");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/user-login.jsp");
			dispatcher.forward(request, response);
		}
		
	}

	private void registerUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// read pharmacist info from form data
		String userName = request.getParameter("userName");
		String pwd = request.getParameter("pwd");
		boolean registeredSuccessfully = false;
		
		boolean isAdmin = false;//because there will be only 1 admin, created from DB. We support signUp for normal users only

		// create a new pharmacist object
		Pharmacist thePharmacist = new Pharmacist(userName, pwd, isAdmin);
		
		// add the pharmacist to the database if not already present
		try {
			registeredSuccessfully = pharmacistDbUtil.registerPharmacist(thePharmacist);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(registeredSuccessfully)
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("/dashboard.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			request.setAttribute("registeredSuccessfully", registeredSuccessfully);
			request.setAttribute("errorMsg", "User already exists");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/user-registration.jsp");
			dispatcher.forward(request, response);
		}
	}
	


}
