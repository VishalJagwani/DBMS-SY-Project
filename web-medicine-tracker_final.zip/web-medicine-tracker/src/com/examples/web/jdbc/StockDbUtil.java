package com.examples.web.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

public class StockDbUtil {

	private DataSource dataSource;

	public StockDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Stock> getStocks() throws Exception {
		
		List<Stock> stocks = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select * from stock order by price";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int id = myRs.getInt("id");
				String drugName = myRs.getString("drugName");
				int quantity = myRs.getInt("quantity");
				int price = myRs.getInt("price");
				String stock_status = myRs.getString("stock_status");
				Date sLastUpdationDate = myRs.getDate("sLastUpdationDate");
				
				// create new stock object
				Stock tempStock = new Stock(id, drugName, quantity, price, stock_status, sLastUpdationDate);
				
				// add it to the list of stocks
				stocks.add(tempStock);				
			}
			
			return stocks;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();   // doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addStock(Stock theStock) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into stock "
					   + "(drugName , quantity , price , stock_status) "
					   + "values (?, ?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			// set the param values for the stock
			myStmt.setString(1, theStock.getDrugName());
			myStmt.setInt(2, theStock.getQuantity());
			myStmt.setInt(3, theStock.getPrice());
			myStmt.setString(4, theStock.getStock_status());
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public Stock getStock(int stockId) throws Exception {

		Stock stock = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected stock
			String sql = "select * from stock where id=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, stockId);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				String drugName = myRs.getString("drugName");
				int quantity = myRs.getInt("quantity");
				int price = myRs.getInt("price");
				String stockStatus = myRs.getString("stock_status");
				Date sLastUpdationDate = myRs.getDate("sLastUpdationDate");
				
				// use the stockId during construction
				stock = new Stock(stockId, drugName, quantity, price, stockStatus, sLastUpdationDate);
			}
			else {
				throw new Exception("Could not find stock id: " + stockId);
			}				
			
			return stock;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void updateStock(Stock theStock) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create SQL update statement
			String sql = "update stock "
						+ "set drugName=?, quantity=?, price=?, stock_status=? "
						+ "where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, theStock.getDrugName());
			myStmt.setInt(2, theStock.getQuantity());
			myStmt.setInt(3, theStock.getPrice());
			myStmt.setString(4, theStock.getStock_status());
			myStmt.setInt(5, theStock.getId());
			
			// execute SQL statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public void deleteStock(String theStockId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// convert stock id to int
			int stockId = Integer.parseInt(theStockId);
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to delete stock
			String sql = "delete from stock where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, stockId);
			
			// execute sql statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}	
	}

	public Stock getStockByName(String drugName) throws Exception {

		Stock stock = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected stock
			String sql = "select * from stock where drugName=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, drugName);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				int stockId = myRs.getInt("id");
				String rsdrugName = myRs.getString("drugName");
				int quantity = myRs.getInt("quantity");
				int price = myRs.getInt("price");
				String stockStatus = myRs.getString("stock_status");
				Date sLastUpdationDate = myRs.getDate("sLastUpdationDate");
				
				// use the stockId during construction
				stock = new Stock(stockId, rsdrugName, quantity, price, stockStatus, sLastUpdationDate);
			}
						
			
			return stock;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}
}

