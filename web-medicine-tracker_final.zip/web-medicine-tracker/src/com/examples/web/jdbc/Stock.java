package com.examples.web.jdbc;

import java.util.Date;

public class Stock {

	private int id;
	private String drugName;
	private int quantity;
	private int price;
	private String stock_status;
	private Date sLastUpdationDate;

	public Stock(String drugName, int quantity,int price, String stock_status) {
		this.drugName = drugName;
		this.quantity = quantity;
		this.price = price;
		this.stock_status = stock_status;
	}

	public Stock(int id, String drugName, int quantity, int price, String stock_status) {
		this.id = id;
		this.drugName = drugName;
		this.quantity = quantity;
		this.price = price;
		this.stock_status = stock_status;
	}
	
	public Stock(int id, String drugName, int quantity, int price, String stock_status, Date sLastUpdationDate) {
		this.id = id;
		this.drugName = drugName;
		this.quantity = quantity;
		this.price = price;
		this.stock_status = stock_status;
		this.sLastUpdationDate = sLastUpdationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	public String getStock_status() {
		return stock_status;
	}

	public void setStock_status(String stock_status) {
		this.stock_status = stock_status;
	}
	
	public Date getsLastUpdationDate() {
		return sLastUpdationDate;
	}

	public void setsLastUpdationDate(Date sLastUpdationDate) {
		this.sLastUpdationDate = sLastUpdationDate;
	}

	@Override
	public String toString() {
		return "Stock [id = " + id + ", drugName = " + drugName + ", quantity = " + quantity + ", price = " + price + ", stock_status = "
				+ stock_status + ", sLastUpdationDate = " + sLastUpdationDate + "]";
	}	
}
