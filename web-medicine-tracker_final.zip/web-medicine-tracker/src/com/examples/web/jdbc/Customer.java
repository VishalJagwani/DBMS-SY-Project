package com.examples.web.jdbc;

import java.util.Date;

public class Customer {

	private int id;
	private String firstName;
	private String lastName;
	private String address;
	private Date cLastUpdationDate;

	// for Add
	public Customer(String firstName, String lastName,String address) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		
	}

	//for update
	public Customer(int id,String firstName, String lastName,String address) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	
	//for getCustomer methods
	public Customer(int id,String firstName, String lastName,String address,Date cLastUpdationDate) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.cLastUpdationDate = cLastUpdationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getcLastUpdationDate() {
		return cLastUpdationDate;
	}

	public void setcLastUpdationDate(Date cLastUpdationDate) {
		this.cLastUpdationDate = cLastUpdationDate;
	}


	@Override
	public String toString() {
		return "Customer [id = " + id + ", firstName = " + firstName + ", lastName = " + lastName + ", address = " + address  + ", cLastUpdationDate = " + cLastUpdationDate + "]";
	}	
}
