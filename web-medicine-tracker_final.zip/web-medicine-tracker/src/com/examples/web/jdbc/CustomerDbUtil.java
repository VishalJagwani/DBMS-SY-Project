package com.examples.web.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

public class CustomerDbUtil {

	private DataSource dataSource;

	public CustomerDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Customer> getCustomers() throws Exception {
		
		List<Customer> customers = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select * from customer";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int id = myRs.getInt("id");
				String firstName = myRs.getString("firstName");
				String lastName = myRs.getString("lastName");
				String address = myRs.getString("address");
				Date cLastUpdationDate = myRs.getDate("cLastUpdationDate");
				
				// create new customer object
				Customer tempCustomer = new Customer(id, firstName, lastName, address, cLastUpdationDate);
				
				// add it to the list of stocks
				customers.add(tempCustomer);				
			}
			
			return customers;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();   // doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addCustomer(Customer theCustomer) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into customer "
					   + "(firstName , lastName , address ) "
					   + "values (?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			// set the param values for the customer
			myStmt.setString(1, theCustomer.getFirstName());
			myStmt.setString(2, theCustomer.getLastName());
			myStmt.setString(3, theCustomer.getAddress());
			
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public Customer getCustomer(int customerId) throws Exception {

		Customer customer = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected customer
			String sql = "select * from customer where id=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, customerId);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				String firstName = myRs.getString("firstName");
				String lastName = myRs.getString("lastName");
				String address = myRs.getString("address");
				Date cLastUpdationDate = myRs.getDate("cLastUpdationDate");
				
				//java.util.Date cLastUpdationDate = new Date(myRs.getDate("cLastUpdationDate").getTime());
				
				// use the customerId during construction
				customer = new Customer(customerId, firstName, lastName, address,cLastUpdationDate);
			}
			else {
				throw new Exception("Could not find customer id: " + customerId);
			}				
			
			return customer;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void updateCustomer(Customer theCustomer) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create SQL update statement
			String sql = "update customer "
						+ "set firstName=?, lastName=?, address=? "
						+ "where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, theCustomer.getFirstName());
			myStmt.setString(2, theCustomer.getLastName());
			myStmt.setString(3, theCustomer.getAddress());
			myStmt.setInt(4, theCustomer.getId());
			
			// execute SQL statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public void deleteCustomer(String theCustomerId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// convert customer id to int
			int customerId = Integer.parseInt(theCustomerId);
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to delete customer
			String sql = "delete from customer where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, customerId);
			
			// execute sql statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}	
	}

	public Customer getCustomerByName(String customerFirstName, String customerLastName) throws Exception {

		Customer customer = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected customer
			String sql = "select * from customer where firstName=? and lastName = ?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, customerFirstName);
			myStmt.setString(2, customerLastName);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				int customerId = myRs.getInt("id");
				String firstName = myRs.getString("firstName");
				String lastName = myRs.getString("lastName");
				String address = myRs.getString("address");
				Date cLastUpdationDate = myRs.getDate("cLastUpdationDate");
				
				// use the customerId during construction
				customer = new Customer(customerId, firstName, lastName, address,cLastUpdationDate);
			}
//			else {
//				throw new Exception("Could not find customer with firstName " + customerFirstName);
//			}				
			
			return customer;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}
}

