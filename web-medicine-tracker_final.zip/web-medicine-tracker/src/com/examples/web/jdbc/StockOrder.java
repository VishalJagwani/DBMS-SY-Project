package com.examples.web.jdbc;

public class StockOrder {

	private int orderId;
	private int stockId;
	private int pharmacistId;
	

	public StockOrder(int orderId) {
		this.orderId = orderId;
	}

	
	public StockOrder(int orderId, int stockId,int pharmacistId) {
		this.orderId = orderId;
		this.stockId = stockId;
		this.pharmacistId = pharmacistId;
	}


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getStockId() {
		return stockId;
	}


	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public int getPharmacistId() {
		return pharmacistId;
	}


	public void setPharmacistId(int pharmacistId) {
		this.pharmacistId = pharmacistId;
	}



	@Override
	public String toString() {
		return "StockOrder [orderId = " + orderId + ", stockId = " + stockId + ", pharmacistId = " + pharmacistId  + "]";
	}	
}
