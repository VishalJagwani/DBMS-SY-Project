package com.examples.web.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

public class StockOrderDbUtil {

	private DataSource dataSource;

	public StockOrderDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<StockOrder> getStockOrders() throws Exception {
		
		List<StockOrder> stockOrders = new ArrayList<>();
		
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// get a connection
			myConn = dataSource.getConnection();
			
			// create sql statement
			String sql = "select * from stockorder";
			
			myStmt = myConn.createStatement();
			
			// execute query
			myRs = myStmt.executeQuery(sql);
			
			// process result set
			while (myRs.next()) {
				
				// retrieve data from result set row
				int orderId = myRs.getInt("orderId");
				int stockId = myRs.getInt("stockId");
				int pharmacistId = myRs.getInt("pharmacistId");
				
				// create new stock_order object
				StockOrder tempStockOrder = new StockOrder(orderId, stockId,pharmacistId);
				
				// add it to the list of stockOrders
				stockOrders.add(tempStockOrder);				
			}
			
			return stockOrders;		
		}
		finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}		
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();   // doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addStockOrder(StockOrder theStockOrder) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create sql for insert
			String sql = "insert into stockorder "
					   + "(orderId , stockId, pharmacistId) "
					   + "values (?, ?, ?)";
			
			myStmt = myConn.prepareStatement(sql);
			
			// set the param values for the stock_order
			myStmt.setInt(1, theStockOrder.getOrderId());
			myStmt.setInt(2, theStockOrder.getStockId());
			myStmt.setInt(3, theStockOrder.getPharmacistId());
			
			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public StockOrder getStockOrderByOrderId(int orderId) throws Exception {

		StockOrder stockOrder = null;
		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		
		
		try {
			
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to get selected stockorder
			String sql = "select * from stockorder where orderId=?";
			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, orderId);
			
			// execute statement
			myRs = myStmt.executeQuery();
			
			// retrieve data from result set row
			if (myRs.next()) {
				int rsOrderId = myRs.getInt("orderId");
				int rsStockId = myRs.getInt("stockId");
				int rsPharmacistId = myRs.getInt("PharmacistId");
				
				// use the orderId during construction
				stockOrder = new StockOrder(rsOrderId, rsStockId, rsPharmacistId);
			}
			else {
				throw new Exception("Could not find order id: " + orderId);
			}				
			
			return stockOrder;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void updateStock(Stock theStock) throws Exception {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			
			// create SQL update statement
			String sql = "update stock "
						+ "set drugName=?, quantity=?, price=?, stock_status=? "
						+ "where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setString(1, theStock.getDrugName());
			myStmt.setInt(2, theStock.getQuantity());
			myStmt.setInt(3, theStock.getPrice());
			myStmt.setString(4, theStock.getStock_status());
			myStmt.setInt(5, theStock.getId());
			
			// execute SQL statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public void deleteStock(String theStockId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		
		try {
			// convert stock id to int
			int stockId = Integer.parseInt(theStockId);
			
			// get connection to database
			myConn = dataSource.getConnection();
			
			// create sql to delete stock
			String sql = "delete from stock where id=?";
			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);
			
			// set params
			myStmt.setInt(1, stockId);
			
			// execute sql statement
			myStmt.execute();
		}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}	
	}

	public OrderDetails createOrderDetails(Order theOrder, Stock theStock, Pharmacist thePharmacist, Customer theCustomer) {
		int orderId = theOrder.getId();
		Date orderDate = theOrder.getOrderDate();
		int orderQuantity = theOrder.getOrderQty();
		int orderTotal = theOrder.getOrderTotal();
		String customerFirstName = theCustomer.getFirstName();
		String customerLastName = theCustomer.getLastName();
		String drugName = theStock.getDrugName();
		String pharmacistName = thePharmacist.getUserName();
		
		OrderDetails orderDetails = new OrderDetails(orderId,orderDate,orderQuantity,orderTotal,customerFirstName,customerLastName,drugName,pharmacistName);
		
		return orderDetails;
	}
}


